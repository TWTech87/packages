/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package agent.dbgeng.impl.dbgeng.symbols;

import java.util.Objects;

import agent.dbgeng.dbgeng.DebugModule;
import agent.dbgeng.dbgeng.DebugModuleInfo;

public class DebugModuleImpl implements DebugModule {
	private final DebugSymbolsInternal symbols;
	final int index;
	final long base;
	DebugModuleInfo info;

	DebugModuleImpl(DebugSymbolsInternal symbols, int index, long base) {
		this.symbols = symbols;
		this.index = index;
		this.base = base;
	}

	@Override
	public int hashCode() {
		return Objects.hash(symbols, index, base);
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof DebugModuleImpl)) {
			return false;
		}
		DebugModuleImpl that = (DebugModuleImpl) obj;
		if (!this.symbols.equals(that.symbols)) {
			return false;
		}
		if (this.index != that.index) {
			return false;
		}
		if (this.base != that.base) {
			return false;
		}
		return true;
	}

	@Override
	public String getName(DebugModuleName which) {
		return symbols.getModuleName(which, this);
	}

	@Override
	public int getIndex() {
		return index;
	}

	@Override
	public long getBase() {
		return base;
	}
}
